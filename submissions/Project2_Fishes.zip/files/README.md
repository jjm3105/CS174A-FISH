# CS174A-FISH

Project 2 for CS174A, Winter 2019. Fish are Friends, not Food  

# Team Members

004769092 Kenny Chan  
404814243 Grand Huynh  
004789797 Jonathan Myong

# Descriptions

This small goldfish will do as they please.
After enabling treat mode, left click to drop treats into the tank.