#! bin/sh

python -m http.server
python -m SimpleHTTPServer